"""
Instructional Agents - Core Modules

This package contains the core functionality for automated course material generation.
"""

__version__ = "1.1.1"

