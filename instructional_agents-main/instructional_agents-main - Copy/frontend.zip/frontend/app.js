/* ==========================================================
   AI COURSE GENERATOR
   Frontend Controller
   Part 1
========================================================== */

const API_BASE = "http://127.0.0.1:8000";

/* ==========================================================
   GLOBAL VARIABLES
========================================================== */

let currentMode = "autonomous";
let taskId = null;
let eventSource = null;
let pollingInterval = null;

let uploadedCatalogName = null;

/* ==========================================================
   DOM ELEMENTS
========================================================== */

const welcomePage = document.getElementById("welcome-page");
const dashboard = document.getElementById("dashboard");

const startBtn = document.getElementById("startBtn");

const cards = document.querySelectorAll(".mode-card");

const generatorForm = document.getElementById("generatorForm");

const courseName = document.getElementById("courseName");

const model = document.getElementById("model");

const catalogUpload =
document.getElementById("catalogUpload");

const copilotUpload =
document.getElementById("copilotUpload");

const catalogFile =
document.getElementById("catalogFile");

const copilotFile =
document.getElementById("copilotFile");

const generatePPT =
document.getElementById("ppt");

const progressSection =
document.getElementById("progressSection");

const progressFill =
document.getElementById("progressFill");

const progressText =
document.getElementById("progressText");

const logsSection =
document.getElementById("logsSection");

const logs =
document.getElementById("logs");

const resultsSection =
document.getElementById("resultsSection");

const results =
document.getElementById("results");

const generateBtn =
document.getElementById("generateBtn");

const completionSection =
document.getElementById("completionSection");

const currentStage =
document.getElementById("currentStage");

const downloadActions =
document.getElementById("downloadActions");

const generateAgainBtn =
document.getElementById("generateAgainBtn");

/* ==========================================================
   INITIALIZE
========================================================== */

window.onload = () => {

    initializeWelcome();

    initializeCards();

    initializeUploads();

};

/* ==========================================================
   WELCOME SCREEN
========================================================== */

function initializeWelcome(){

    startBtn.addEventListener("click",()=>{

        welcomePage.style.opacity="0";

        setTimeout(()=>{

            welcomePage.style.display="none";

            dashboard.classList.remove("hidden");

            dashboard.style.opacity="0";

            setTimeout(()=>{

                dashboard.style.opacity="1";

            },100);

        },600);

    });

}

/* ==========================================================
   CARD SELECTION
========================================================== */

function initializeCards(){

    cards.forEach(card=>{

        card.addEventListener("click",()=>{

            cards.forEach(c=>{

                c.classList.remove("active");

            });

            card.classList.add("active");

            currentMode =
            card.dataset.mode;

            switch(currentMode){

                case "autonomous":

                    catalogUpload.classList.add("hidden");

                    copilotUpload.classList.add("hidden");

                    break;

                case "catalog":

                    catalogUpload.classList.remove("hidden");

                    copilotUpload.classList.add("hidden");

                    break;

                case "copilot":

                    copilotUpload.classList.remove("hidden");

                    catalogUpload.classList.add("hidden");

                    break;

            }

        });

    });

}

/* ==========================================================
   FILE UPLOADS
========================================================== */

function initializeUploads(){

    catalogFile.addEventListener("change",async()=>{

        if(catalogFile.files.length===0)
            return;

        await uploadCatalog();

    });

}
/* ==========================================================
   RESET UI
========================================================== */

function resetUI(){

    progressFill.style.width="0%";

    progressText.innerHTML="0%";

    logs.innerHTML="";

    results.innerHTML="";

    progressSection.classList.add("hidden");

    logsSection.classList.add("hidden");

    resultsSection.classList.add("hidden");

}

/* ==========================================================
   SHOW UI
========================================================== */

function showGenerationUI(){

    progressSection.classList.remove("hidden");

    logsSection.classList.remove("hidden");

    resultsSection.classList.remove("hidden");

}

/* ==========================================================
   ADD LOG
========================================================== */

function addLog(message){

    logs.innerHTML += message + "<br>";

    logs.scrollTop = logs.scrollHeight;

}

/* ==========================================================
   UPDATE PROGRESS
========================================================== */

function updateProgress(value){

    progressFill.style.width=value+"%";

    progressText.innerHTML=value+"%";

}

/* ==========================================================
   DISABLE BUTTON
========================================================== */

function setGenerating(flag){

    generateBtn.disabled=flag;

    if(flag){

        generateBtn.innerHTML="Generating...";

    }else{

        generateBtn.innerHTML="Generate";

    }

}
/* ==========================================================
   UPLOAD CATALOG
========================================================== */

async function uploadCatalog() {

    try {

        addLog("Uploading catalog...");

        const formData = new FormData();

        formData.append(
            "file",
            catalogFile.files[0]
        );

        const response = await fetch(
            API_BASE + "/api/catalog/upload",
            {
                method: "POST",
                body: formData
            }
        );

        const data = await response.json();

        if (!response.ok) {

            throw new Error(
                data.detail || "Upload failed"
            );

        }

        uploadedCatalogName = data.filename;

        addLog("Catalog uploaded successfully.");

    }

    catch (err) {

        alert(err.message);

    }

}
/* ==========================================================
   BUILD REQUEST
========================================================== */

async function buildRequest() {

    const request = {

        course_name:
            courseName.value.trim(),

        model_name:
            model.value,

        exp_name:
            "frontend_" + Date.now(),

        generate_pptx:
            generatePPT.checked,

        copilot:false,

        catalog:null,

        catalog_data:null

    };



    if(currentMode==="catalog"){

        if(catalogFile.files.length===0){

            alert("Please upload catalog JSON.");

            return null;

        }

        request.catalog =
            uploadedCatalogName;

    }



    if(currentMode==="copilot"){

        if(copilotFile.files.length===0){

            alert("Please upload Copilot JSON.");

            return null;

        }

        const text =
        await copilotFile.files[0].text();

        request.copilot=true;

        request.catalog_data=
            JSON.parse(text);

    }

    return request;

}
/* ==========================================================
   FORM SUBMIT
========================================================== */

generatorForm.addEventListener(

    "submit",

    async function(e){

        e.preventDefault();

        if(courseName.value.trim()===""){

            alert("Enter course name");

            return;

        }

        resetUI();

        showGenerationUI();

        setGenerating(true);

        try{

            const request=
            await buildRequest();

            if(request==null){

                setGenerating(false);

                return;

            }

            startGeneration(request);

        }

        catch(err){

            alert(err.message);

            setGenerating(false);

        }

    }

);
/* ==========================================================
   START GENERATION
========================================================== */

async function startGeneration(request){

    addLog("Starting generation...");

    try{

        const response=await fetch(

            API_BASE+"/api/course/generate",

            {

                method:"POST",

                headers:{

                    "Content-Type":"application/json"

                },

                body:JSON.stringify(request)

            }

        );



        const data=

        await response.json();

        if(!response.ok){

            throw new Error(

                data.detail ||

                "Generation failed"

            );

        }

        taskId=data.task_id;

        addLog(

            "Task ID : "+taskId

        );



        connectLogStream();

        startPolling();

    }

    catch(err){

        setGenerating(false);

        alert(err.message);

    }

}
/* ==========================================================
   CONNECT TO SSE LOG STREAM
========================================================== */

function connectLogStream() {

    if (eventSource) {

        eventSource.close();

    }

    eventSource = new EventSource(

        API_BASE +
        "/api/course/logs/" +
        taskId +
        "/stream"

    );

    eventSource.onmessage = function (event) {

        const data = JSON.parse(event.data);

        switch (data.type) {

            case "connected":

                addLog("Connected to log stream.");

                break;

            case "log":

                addLog(data.message);

                break;

            case "complete":

                addLog("Generation Finished.");

                eventSource.close();

                break;

            case "error":

                addLog("ERROR : " + data.message);

                break;

        }

    };

    eventSource.onerror = function () {

        addLog("Log stream disconnected.");

    };

}
/* ==========================================================
   POLL TASK STATUS
========================================================== */

function startPolling() {

    if (pollingInterval) {

        clearInterval(pollingInterval);

    }

    pollingInterval = setInterval(

        checkStatus,

        2000

    );

}
/* ==========================================================
   CHECK TASK STATUS
========================================================== */

/* ==========================================================
   CHECK TASK STATUS
========================================================== */

async function checkStatus() {

    if (!taskId) return;

    try {

        const response = await fetch(
            API_BASE +
            "/api/course/status/" +
            taskId
        );

        if (!response.ok) {

            throw new Error(
                "Unable to fetch task status."
            );

        }

        const data = await response.json();

        /* --------------------------
           Progress
        -------------------------- */

        updateProgress(
            data.progress || 0
        );
        if (data.current_stage) {

    document.getElementById("currentStage").innerHTML =
        data.current_stage;

}

        /* --------------------------
           Current Stage
        -------------------------- */

        if (data.current_stage) {

            const stage =
                document.getElementById("currentStage");

            if (stage) {

                stage.innerHTML =
                    data.current_stage;

            }

        }

        /* --------------------------
           Refresh Results
        -------------------------- */

        await refreshResults();

        /* --------------------------
           Task Status
        -------------------------- */

        switch (data.status) {

            case "pending":

                break;

            case "starting":

                break;

            case "running":

                break;

            case "completed":

                clearInterval(
                    pollingInterval
                );

                pollingInterval = null;

                updateProgress(100);

                

                addLog(
                    "Course generation completed successfully."
                );

                setGenerating(false);

                if (eventSource) {

                    eventSource.close();

                    eventSource = null;

                }

                const complete =
                    document.getElementById(
                        "completionSection"
                    );

                if (complete) {

                    complete.classList.remove(
                        "hidden"
                    );

                }

                break;

            case "failed":

                clearInterval(
                    pollingInterval
                );

                pollingInterval = null;

                setGenerating(false);

                if (eventSource) {

                    eventSource.close();

                    eventSource = null;

                }

                addLog(
                    "Generation failed."
                );

                if (data.error) {

                    addLog(
                        data.error
                    );

                }

                break;

            default:

                break;

        }

    }

    catch (error) {

        console.error(error);

        addLog(
            "Unable to connect to the server."
        );

    }

}
/* ==========================================================
   LOAD GENERATED FILES
========================================================== */

async function loadResults() {

    try {

        const response = await fetch(

            API_BASE +
            "/api/course/results/" +
            taskId +
            "/files"

        );

        const data = await response.json();

        if (!response.ok) {

            throw new Error(data.detail);

        }

        renderChapterCards(data.files);

    }

    catch (err) {

        console.error(err);

    }

}
/* ==========================================================
   DOWNLOAD FILE
========================================================== */

function downloadFile(path) {

    window.open(

        API_BASE +

        "/api/course/results/" +

        taskId +

        "/download/" +

        path,

        "_blank"

    );

}
/* ==========================================================
   LIVE RESULTS
========================================================== */



async function refreshResults() {

    if (!taskId) return;

    try {

        const response = await fetch(

            API_BASE +
            "/api/course/results/" +
            taskId +
            "/files"

        );

        if (!response.ok) return;

        const data = await response.json();

        renderChapterCards(data.files);

    }

    catch (e) {

        console.log(e);

    }

}
/* ==========================================================
   GROUP FILES
========================================================== */

function groupByChapter(files) {

    const grouped = {};

    files.forEach(file => {

        const path = file.path.replace(/\\/g,"/");

        const parts = path.split("/");

        let chapter = "Other";

        if(parts.length > 1){

            chapter = parts[0];

        }

        if(!grouped[chapter]){

            grouped[chapter]=[];

        }

        grouped[chapter].push(file);

    });

    return grouped;

}
/* ==========================================================
   RENDER CHAPTERS
========================================================== */

function renderChapterCards(files){
    createDownloadActions(files);

    const grouped = groupByChapter(files);

    results.innerHTML="";

    Object.keys(grouped)
    .sort((a, b) =>
        a.localeCompare(b, undefined, { numeric: true })
    ).forEach(chapter=>{

        const card=document.createElement("div");

        card.className="chapter-card";

        const title=document.createElement("h4");

        title.innerText=chapter;

        card.appendChild(title);

        const table=document.createElement("table");

        table.className="resultTable";

        table.innerHTML=`

        <thead>

        <tr>

        <th>File</th>

        <th>Type</th>

        <th>Action</th>

        </tr>

        </thead>

        `;

        const body=document.createElement("tbody");

        grouped[chapter].forEach(file=>{

            body.appendChild(

                createRow(file)

            );

        });

        table.appendChild(body);

        card.appendChild(table);

        results.appendChild(card);

    });

}
/* ==========================================================
   CREATE TABLE ROW
========================================================== */

function createRow(file){

    const tr=document.createElement("tr");

    const td1=document.createElement("td");

    const td2=document.createElement("td");

    const td3=document.createElement("td");

    td1.innerHTML=

    cleanFileName(file.name);

    td2.innerHTML=

    getFileType(file.type);

    const btn=document.createElement("button");

    btn.className="downloadBtn";

    btn.innerHTML="Download";

    btn.onclick=function(){

        downloadFile(file.path);

    };

    td3.appendChild(btn);

    tr.appendChild(td1);

    tr.appendChild(td2);

    tr.appendChild(td3);

    return tr;

}
/* ==========================================================
   FILE NAME
========================================================== */

function cleanFileName(name){

    const lower=name.toLowerCase();

    if(lower.includes("slides") && lower.endsWith(".pptx"))

        return "Presentation";

    if(lower.includes("slides"))

        return "Slides";

    if(lower.includes("script"))

        return "Script";

    if(lower.includes("assessment"))

        return "Assessment";

    return name;

}
/* ==========================================================
   FILE TYPE
========================================================== */

function getFileType(type){

    switch(type){

        case ".tex":

            return "TEX";

        case ".md":

            return "Markdown";

        case ".pptx":

            return "PPTX";

        case ".pdf":

            return "PDF";

        case ".json":

            return "JSON";

        default:

            return type.replace(".","").toUpperCase();

    }

}
/* ==========================================================
   GENERATE AGAIN
========================================================== */

const generateAgainBtn =
document.getElementById("generateAgainBtn");

if(generateAgainBtn){

    generateAgainBtn.addEventListener("click",()=>{

        taskId=null;

        if(eventSource){

            eventSource.close();

            eventSource=null;

        }

        if(pollingInterval){

            clearInterval(pollingInterval);

            pollingInterval=null;

        }

        resetUI();

        courseName.value="";

        catalogFile.value="";

        copilotFile.value="";

        generatePPT.checked=false;

        uploadedCatalogName=null;

        completionSection.classList.add("hidden");

dashboard.scrollIntoView({

    behavior:"smooth"

});

    });

}
/* ==========================================================
   DOWNLOAD ALL
========================================================== */

function createDownloadActions(files){

    const container=document.getElementById(

        "downloadActions"

    );

    if(!container) return;

    container.innerHTML="";

    const pptx=files.filter(

        f=>f.type==".pptx"

    );

    const pdf=files.filter(

        f=>f.type==".pdf"

    );

    if(pptx.length){

        const btn=document.createElement("button");

        btn.className="downloadBtn";

        btn.innerHTML="Download All PPTX";

        btn.onclick=()=>{

            pptx.forEach(file=>{

                downloadFile(file.path);

            });

        };

        container.appendChild(btn);

    }

    if(pdf.length){

        const btn=document.createElement("button");

        btn.className="downloadBtn";

        btn.innerHTML="Download All PDF";

        btn.onclick=()=>{

            pdf.forEach(file=>{

                downloadFile(file.path);

            });

        };

        container.appendChild(btn);

    }

}