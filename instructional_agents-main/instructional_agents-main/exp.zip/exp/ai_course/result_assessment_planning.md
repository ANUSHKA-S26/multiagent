Assessment & Evaluation Planning
================================

**Foundations of Artificial Intelligence Course Assessment Plan**

**Objective:**

To assess students' knowledge, skills, and abilities in applying AI concepts, programming principles, and development frameworks to real-world problems.

**Assessment Types:**

1. **Participation and Engagement** (20 points)
	* Attendance at lectures and lab sessions (5 points)
	* Class discussions and participation (5 points)
	* Email submissions of weekly reflections (5 points)
	* Peer review and feedback (5 points)
2. **Homework and Lab Assignments** (30 points)
	* Completion of homework exercises and lab assignments (10 points)
	* Submission of code and incremental projects (5 points each)
	* Email submission of written reflections (2 points each)
	* Peer review and feedback (5 points)
3. **Team Project** (25 points)
	* Development of a complete AI project (15 points)
	* Presentations (5 points)
	* Written reports and documentation (5 points)
4. **Final Exam** (25 points)
	* Written exam assessing students' understanding of AI concepts, programming principles, and AI development frameworks (25 points)

**Grading Criteria:**

1. **Application of AI concepts to real-world problems** (4 points)
	* Can students analyze and formulate problems that can be solved using AI methodologies? (2 points)
	* Can students design and implement basic AI systems to address specific industry or societal needs? (2 points)
2. **Understanding and application of programming concepts** (6 points)
	* Can students apply programming concepts and skills in popular AI development platforms? (3 points)
	* Can students implement AI algorithms and techniques for machine learning, natural language processing, computer vision, and other core AI subfields? (3 points)
3. **Data analysis and interpretation** (6 points)
	* Can students analyze and interpret AI results and data using statistical analysis and model evaluation techniques? (3 points)
	* Can students communicate complex AI ideas to technical and non-technical audiences? (3 points)
4. **Collaboration and communication** (4 points)
	* Can students demonstrate effective collaboration and communication skills in AI projects? (2 points)
	* Can students articulate complex AI ideas to technical and non-technical audiences? (2 points)

**Grading Rubrics:**

Detailed grading rubrics for each assessment component can be found in the course learning management system (LMS).

**Submission and Evaluation Logistics:**

* Students will submit their work electronically through the Canvas LMS.
* Students will receive regular feedback on their assignments and progress.
* The final exam will be written and comprehensive, evaluating students' understanding of AI concepts, programming principles, and AI development frameworks.
* The evaluation will be fair, unbiased, and anonymous to ensure a level playing field for all students.

**Culminating Assessment:**

The culminating assessment will be the final project, where students will work in teams to design, implement, and present a complete AI project. The project will demonstrate students' knowledge, skills, and abilities in applying AI concepts, programming principles, and development frameworks to real-world problems.

**Assessment Accommodations:**

The course instructor will provide accommodations for students with disabilities, language barriers, or those who require accommodations due to personal circumstances. Provisions for accommodations will be made on a case-by-case basis.

**Integration with Course Learning Objectives:**

Each assessment component is explicitly connected to the specific learning objectives, ensuring that students are assessed on their mastery of the specific skills and knowledge.

**Industry Insights and Trends:**

The assessment components reflect the rapidly evolving field of AI and incorporate up-to-date industry trends, insights, and best practices.