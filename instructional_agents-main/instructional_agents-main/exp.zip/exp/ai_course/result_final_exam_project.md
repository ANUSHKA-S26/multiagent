Final Project Assessment Design
===============================

**Final Project: "AI-driven Solution for a Real-World Problem"**

**Project Description:**

The final project assesses students' knowledge, skills, and abilities in applying AI concepts, programming principles, and development frameworks to real-world problems. Students will choose a real-world problem, design, implement, and present an AI-driven solution using relevant AI development platforms, algorithms, and techniques.

**Objectives:**

1. Apply AI concepts to real-world problems.
2. Design, implement, and present an AI-driven solution.
3. Utilize AI development platforms, algorithms, and techniques.
4. Collect, analyze, and interpret data to support the solution.
5. Communicate complex AI ideas to technical and non-technical audiences.

**Timeline with Milestones:**

1. **Proposal (5% of final grade)**: Due Week 4
	* Format: PDF (.pdf)
	* Requirements:
		+ Problem statement (1 page)
		+ Objectives (1 page)
		+ Methodology (1 page)
	* Minimum word count: 500 words
2. **Progress Update (5% of final grade)**: Due Week 8
	* Format: PDF (.pdf) or written reflection in Canvas
	* Requirements:
		+ Progress on the project (1 page)
		+ Challenges and insights gained (1 page)
3. **Final Deliverable (40% of final grade)**: Due Week 12
	* Format:
		+ Written report (Word, PDF)
		+ Code (GitHub repository)
		+ Presentation (video recording or PPTX/PDF)
	* Requirements:
		+ AI methodology
		+ Data analysis and interpretation
		+ Communication and collaboration

**Deliverables:**

1. Proposal
2. Progress Update
3. Final Deliverable (written report, code, and presentation)

**Grading Rubric:**

1. Proposal (20 points):
	* Problem statement (5 points)
	* Objectives (5 points)
	* Methodology (5 points)
	* Format and clarity (5 points)
2. Progress Update (20 points):
	* Progress on the project (5 points)
	* Challenges and insights gained (5 points)
	* Format and clarity (5 points)
	* Progress toward objectives (5 points)
3. Final Deliverable (60 points):
	* AI methodology (15 points)
	* Data analysis and interpretation (15 points)
	* Communication and collaboration (15 points)
	* Overall presentation (15 points)

**Submission Formats:**

1. Proposal: PDF (.pdf)
2. Progress Update: PDF (.pdf) or written reflection in Canvas
3. Final Deliverable: Written report (Word, PDF), code (GitHub repository), and presentation (video recording or PPTX/PDF)

**Canvas LMS Compatibility:**

1. Proposal and Progress Update: Canvas assignments with clear instructions and submission requirements
2. Final Deliverable: Canvas submissions with peer review and feedback mechanisms

**Peer/Instructor Feedback:**

1. Peer review and feedback will be encouraged throughout the project milestones.
2. Instructors will provide detailed feedback on each project milestone, highlighting strengths, weaknesses, and areas for improvement.

**Academic Integrity Guidelines:**

1. Plagiarism and copyright infringement will not be tolerated.
2. Students must cite and reference all sources, including data and code.
3. Code and data sharing will be encouraged to foster a community of practice and support peer learning.