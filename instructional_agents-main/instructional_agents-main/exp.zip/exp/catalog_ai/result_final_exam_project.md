Final Project Assessment Design
===============================

**Final Project Plan: Real-World AI Applications**

**Project Title:** Real-World AI Applications

**Objective:**

By the end of the course, students will be able to demonstrate their understanding of AI concepts, design and implement efficient search algorithms, apply machine learning basics to solve real-world problems, create effective knowledge representations for AI systems, and explain the principles and applications of deep learning concepts.

**Project Format:**

* Individual project submissions (no team projects)
* Final project report in PDF format (max 15 pages)
* Final project presentation in PowerPoint or similar software (max 10 slides)

**Project Milestones:**

1. **Project Proposal (10%):** Students will submit a project proposal that outlines the problem statement, objectives, and methodology for their final project. (Due Week 6)
2. **Mid-Term Project Update (15%):** Students will submit an update on their project progress, including the current state of their project and any challenges they have faced. (Due Week 12)
3. **Final Project Report and Presentation (75%):** Students will submit a written report and a presentation of their final project, demonstrating their understanding of AI concepts and the ability to design and implement efficient search algorithms, machine learning models, and knowledge representation systems. (Due Week 14)

**Assessment Rubric:**

* Technical accuracy and completeness (40%):
	+ Correctness and efficiency of search algorithms (20%)
	+ Accuracy and completeness of machine learning models (30%)
	+ Effectiveness and efficiency of knowledge representation systems (10%)
* Originality and creativity of the approach (20%):
	+ Novelty and contribution of the project (20%)
	+ Innovation and creativity of the AI solution (30%)
	+ Impeccable organization and structure of the project (20%)
* Clarity and coherence of write-up and presentation (20%):
	+ Clarity and coherence of the written report (20%)
	+ Clarity and coherence of the presentation (20%)
	+ Highly structured and organized project (30%)
* Depth of analysis and understanding (20%):
	+ Depth of analysis and understanding of AI concepts (30%)
	+ Depth of analysis and understanding of search algorithms (20%)
	+ Depth of analysis and understanding of machine learning basics (30%)

**Deliverables:**

1. Final project report (PDF, max 15 pages)
2. Final project presentation (PowerPoint or similar software, max 10 slides)

**Submission Format:**

1. Final project report and presentation will be submitted in PDF and PPT/PPTX formats, respectively.

**Late Submission and Make-up Work:**

Prior approval from the instructor is required for late submissions and make-up work.

**Policies and Adjustments:**

1. **Plagiarism and Academic Integrity:** Strict adherence to the University's policy on academic integrity is expected.
2. **Assessment:** The course will follow the University's policies and procedures for accommodations, assessments, and course adjustments.
3. **Technology Requirements:** Students are responsible for ensuring they have the necessary hardware and software to complete course requirements.

**Grading Rubric:**

* Technical accuracy and completeness: 40%
* Originality and creativity of the approach: 20%
* Clarity and coherence of write-up and presentation: 20%
* Depth of analysis and understanding: 20%

**Academic Integrity Guidelines:**

 Strict adherence to the University's policy on academic integrity is expected. Students are required to acknowledge the original work and references used in their projects.

**Contact Information:**

Instructor's contact information will be provided in the course learning management system.