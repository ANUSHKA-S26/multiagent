Syllabus & Learning Objectives Design
=====================================

**Course Title:** Artificial Intelligence

**Course Number:** CSE 302

**Course Level:** B.Tech 3rd Year

**Credits:** 4

**Semester:** 6th

**Program:** B.Tech CSE

**Course Description:** This course provides an in-depth understanding of Artificial Intelligence (AI) concepts, including search algorithms, machine learning basics, and deep learning fundamentals. Students will learn to design, implement, and evaluate AI systems using a combination of theory and practical applications.

**Course Goals:**

1. **Demonstrate a thorough understanding of AI fundamentals**, including the definition, types, applications, and evolution of artificial intelligence concepts.
2. **Design and implement efficient search algorithms**: Students will be able to describe the different types of search algorithms (e.g., breadth-first search, depth-first search, A\* algorithm) and their applications.
3. **Apply machine learning basics to solve real-world problems**: Students will be able to design and train a simple neural network using a dataset (e.g., MNIST, CIFAR-10).
4. **Create effective knowledge representations for AI systems**: Students will be able to describe the different types of knowledge representations (e.g., rules, objects, first-order logic) and their applications.
5. **Explain the principles and applications of deep learning concepts**: Students will be able to describe the different types of deep learning architectures (e.g., convolutional neural networks, recurrent neural networks, transformers) and their applications.

**Course Topics:**

1. **Introduction to AI**: Definition, types, applications, and evolution of AI.
2. **Intelligent Agents**: Design and implementation of intelligent agents using search algorithms and machine learning basics.
3. **Search Algorithms**: Breadth-first search, depth-first search, A\* algorithm, and their applications.
4. **Machine Learning Basics**: Supervised and unsupervised learning concepts, neural networks, and their applications.
5. **Deep Learning Basics**: Convolutional neural networks, recurrent neural networks, transformers, and their applications.
6. **Knowledge Representation**: Rules, objects, first-order logic, and semantic networks.

**Required Readings:**

* *Introduction to Artificial Intelligence*, by L. Davis and E. Ostermayer.
* *Machine Learning*, by T. Mitchell.
* *Deep Learning: A Comprehensive Guide*, by A.Y. Ng.
* *Knowledge Representation: A Brief Survey*, by N. Lebowitz.

**Software and Hardware Requirements:**

* Python programming language and supporting libraries.
* TensorFlow or PyTorch for deep learning implementation.
* High-performance computing resources (e.g., computing clusters or cloud-based services).
* Access to computing resources for AI and deep learning projects.
* Graphics Processing Units (GPUs) for accelerated computing.
* High-performance computing clusters or nodes for large-scale data processing.
* Internet connectivity for online resources and services.

**Assessment Methods:**

1. **Quizzes (30%):** Students will be assessed on their understanding of AI fundamentals, search algorithms, machine learning basics, knowledge representation, and deep learning concepts.
2. **Assignments (30%):** Students will be assessed on their ability to design and implement search algorithms, machine learning models, and knowledge representation systems.
3. **Mid-term and Final Exams (20%):** Students will be assessed on their understanding of AI concepts, search algorithms, machine learning basics, knowledge representation, and deep learning concepts.
4. **Project Performance (20%):** Students will be assessed on their ability to create effective knowledge representations for AI systems and develop a deep learning model using a dataset.

**Course Schedule:**

| Week 1 | Topic | Assessment |
| --- | --- | --- |
| 1-2 | Introduction to AI, Intelligent Agents, and Search Algorithms | Quiz 1 |
| 3-4 | Breadth-first search and Depth-first search | Assignment 1 |
| 5-6 | A\* Algorithm, Machine Learning Basics, and Supervised Learning | Quiz 2 |
| 7-8 | Unsupervised Learning, Neural Networks, and Convolutional Neural Networks | Assignment 2 |
| 9-10 | Recurrent Neural Networks, Transformers, and Knowledge Representation | Quiz 3 |
| 11-12 | Final Project Workshops and Presentations | Final Project |
| 13-14 | Review, Final Exams, and Project Presentations | Mid-term and Final Exams |

**Collaboration and Feedback:**

* Regular feedback mechanisms will be provided to assess student progress and address potential knowledge gaps.
* Collaborative learning and group discussions will be encouraged to enhance peer learning and understanding.

**Industry Partnerships:**

* Industry experts will provide real-world examples and insights on AI and machine learning applications.
* Partners will collaborate with the course instructors to design and develop relevant coursework and projects.

**Office Hours:**

* Instructor's office hours will be announced at the beginning of the semester.
* Team office hours will be scheduled to accommodate group discussions and feedback.

**Textbook and Reference Materials:**

* Required textbooks and reference materials will be announced at the beginning of the semester.
* Additional resources will be provided through the course learning management system.

**Policies and Adjustments:**

* The course will follow the University's policies and procedures for accommodations, assessments, and course adjustments.

**Undertaking this Course:**

By enrolling in this course, students acknowledge that they have read and understood the course syllabus, including the course objectives, topics, required readings, assessment methods, and policies.

**Shifts in Course Direction:**

The course may be adjusted and refined as needed to ensure that students meet the course learning objectives and outcomes.

**Additional Notes:**

* Plagiarism and Academic Integrity: Strict adherence to the University's policy on academic integrity is expected.
* Late submissions and make-up work: Prior approval from the instructor is required for late submissions and make-up work.
* Technology requirements: Students are responsible for ensuring they have the necessary hardware and software to complete course requirements.