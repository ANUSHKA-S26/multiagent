Assessment & Evaluation Planning
================================

**Course Assessment Planning Document**

**Course Title:** Machine Learning

**Course Description:** This course provides an in-depth introduction to machine learning concepts and their applications in real-world problems.

**Course Objectives:**

1.  Students will be able to apply machine learning concepts to solve real-world problems.
2.  Students will develop a deeper understanding of machine learning algorithms and their applications.
3.  Students will cultivate essential skills in research, analysis, and communication.

**Assessment Types:**

*   Project-based assessment
*   Quizzes
*   Assignments
*   Final exam

**Milestone Structure:**

1.  **Week 3 (Proposal Submission):** Students will submit a proposal outlining their project idea, problem statement, and expected outcomes (5%).
2.  **Week 6 (Progress Report Submission):** Students will submit a progress report highlighting their data collection and preprocessing efforts, feature engineering techniques used, and model selection methods employed (5%).
3.  **Week 10 (Midterm Presentation):** Students will present their project progress to the class, highlighting their strengths and challenges (5%).
4.  **Week 13 (Final Report Submission):** Students will submit their final report, including their project overview, methodological details, results, and conclusions (10%).
5.  **Week 14 (Final Presentation):** Students will present their final project to the class, highlighting their results and insights (5%).

**Grading Criteria:**

1.  **Ideation and Problem Statement (20%):** The effectiveness of the problem statement, relevance to the chosen domain, and originality of the idea.
2.  **Data Collection and Preprocessing (20%):** The quality of the dataset, thoroughness of data preprocessing efforts, and feature engineering techniques used.
3.  **Model Selection and Training (25%):** The appropriateness of the chosen model, effectiveness of hyperparameter tuning, and robustness of the trained model.
4.  **Results and Insights (20%):** The clarity of the results presentation, depth of analysis, and meaningful insights gained from the project.
5.  **Communication and Presentation (15%):** Clarity of the written report, effectiveness of the oral presentation, and confidence in presenting the project.

**Submission Formats:**

*   PDF format through Canvas for proposal, progress reports, and final report.
*   In-class presentations for midterm and final presentations.

**Delivery Platforms:**

*   Canvas will be used for submitting proposal, progress reports, and final report.
*   In-class presentations will be conducted in a classroom setting.

**Weightage of Assessment:**

*   Project-based assessment: 30%
*   Quizzes, assignments, and final exam: 70%

By following this course assessment planning document, students will be able to apply machine learning concepts to solve real-world problems, develop a deeper understanding of the subject, and cultivate essential skills in research, analysis, and communication.